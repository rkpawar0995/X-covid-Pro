package xyz.rkplap.covidpro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class HomeActivity extends AppCompatActivity {

    private ImageView scn,abt,lg,hlp,hlt;
    private ImageView pform;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        scn = (ImageView) findViewById(R.id.btnscan);
        pform = (ImageView) findViewById(R.id.frm);
        hlp = (ImageView) findViewById(R.id.help);
        abt = (ImageView) findViewById(R.id.abt);
        lg = (ImageView) findViewById(R.id.logout);
        hlt = (ImageView) findViewById(R.id.care);

        scn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this,ScanActivity.class);
                startActivity(i);
            }
        });

        hlp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this,healthActivity.class);
                startActivity(i);
            }
        });


        abt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this,AboutActivity.class);
                startActivity(i);
            }
        });

        lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this,MainActivity.class);
                startActivity(i);
            }
        });


    }
}
